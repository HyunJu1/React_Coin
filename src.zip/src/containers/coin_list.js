import React, {Component} from 'react';
import {connect} from 'react-redux';

class CoinList extends Component {
  renderCoin({coinData}){
    console.log('여기까진 왔나?')
    console.log('coin'+coinData.index);
    // const name=this.coinData.map(e=>(e.name));
    // const price_usd=coinDatas.map(e=>(e.price_usd));
    // const percent_change_1h=this.props.map(e=>(e.percent_change_1h));
    
    return (
      
      <tr key={coinData.index}>
        <th>{coinData.name}</th>
        <th>${coinData.price_usd}</th>
        <th>{coinData.classNamepercent_change_1h}</th> 
        {/* <th>{ind.percent_change_24h}</th>
        <th>{ind.percent_change_7d}</th>   */}
      </tr>
    );
  }
  handleError(){
    if(this.props.error){
      this.return(
        <div className="alert alert-danger" role="alert">
          {this.props.error.message}
        </div>
      );
    }
  }

  render(){
    return (
      <div className='coin-list'>
        {this.handleError()}
        <table className='table table-hover'>
          <thead>
            <tr>
              <th>이름</th>
              <th>가격</th>
              <th>변동가(1H)</th>
              <th>변동가(1D)</th>
              <th>변동가(1W)</th>
            </tr>
          </thead>
          <tbody>
            {this.props.coin.map(this.renderCoin)}
          </tbody>
        </table>
      </div>
    );
  }
}

function mapStateToProps(state){
  console.log('state:'+state);
  return {

    coin:state.coin.data,
    error:state.coin.error
  };
}

export default connect(mapStateToProps)(CoinList);