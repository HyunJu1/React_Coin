import {FETCH_COIN} from '../actions/index';

export default function(state={
  loading:false, error:'', data:[]
},action){
  console.log('action:'+action);
  switch(action.type){
  case `${FETCH_COIN}_PENDING`:
    return {
      loading: false,
      error:'',
      data:[...state.data]
    };
  case `${FETCH_COIN}_FULFILLED`:
    return {
      loading: false,
      error:'',
      data:[action.payload.data, ...state.data]
    };
  case `${FETCH_COIN}_REJECTED`:
    return{
      loading :false,
      error: action.payload,
      data:[...state.data]
    };
  default:
    return state;
  }
}